package response

import (
	"encoding/json"
	"net/http"

	"github.com/gogf/gf/v2/errors/gcode"
)

// Data 结构体用于封装HTTP响应的数据
type Data struct {
	Code    int    `json:"code"`
	Message string `json:"message"`
	Data    any    `json:"data"`
}

// ResponseWriter 接口定义了处理HTTP响应的方法
type ResponseWriter interface {
	// Status 返回当前响应的状态码
	Status() int

	// Errcode 返回当前响应的错误码
	Errcode() int

	// ResponseSuccess 用于写入成功的响应
	ResponseSuccess(data any) error

	// ResponseErrcode 用于写入错误的响应
	ResponseErrcode(code gcode.Code) error
}

// responseWriter 结构体实现了ResponseWriter接口
type responseWriter struct {
	w          http.ResponseWriter
	statusCode int
	errcode    gcode.Code
}

// NewResponseWriter 创建一个新的ResponseWriter实例
func NewResponseWriter(w http.ResponseWriter) ResponseWriter {
	return &responseWriter{
		w:          w,
		statusCode: http.StatusOK,
	}
}

// Status 返回当前响应的状态码
func (rw *responseWriter) Status() int {
	return rw.statusCode
}

// Errcode 返回当前响应的错误码
func (rw *responseWriter) Errcode() int {
	if rw.errcode == nil {
		return 0
	}
	return rw.errcode.Code()
}

// ResponseSuccess 用于写入成功的响应
func (rw *responseWriter) ResponseSuccess(data any) error {
	return rw.response(0, "success", data, http.StatusOK)
}

// ResponseErrcode 用于写入错误的响应
func (rw *responseWriter) ResponseErrcode(code gcode.Code) error {
	rw.errcode = code
	return rw.response(code.Code(), code.Message(), nil, http.StatusOK)
}

// response 是一个私有方法，用于处理HTTP响应的写入
func (rw *responseWriter) response(code int, message string, data any, status int) error {
	resp := Data{
		Code:    code,
		Message: message,
		Data:    data,
	}
	respData, err := json.Marshal(resp)
	if err != nil {
		return err
	}

	rw.statusCode = status
	rw.w.WriteHeader(status)
	_, writeErr := rw.w.Write(respData)

	return writeErr
}
