package lists

import (
	"context"
	"github.com/alicebob/miniredis/v2"
	"github.com/redis/go-redis/v9"
	"sync"
)

type Lists struct {
	rdb *redis.Client
}

var gRdb *Lists
var once = sync.OnceValue(newLists)

func GetLists() *Lists {
	return once()
}

func newLists() *Lists {
	mRdb := miniredis.NewMiniRedis()
	err := mRdb.Start()
	if err != nil {
		panic(err)
	}

	gRdb = &Lists{rdb: redis.NewClient(&redis.Options{Addr: mRdb.Addr()})}

	return gRdb
}

func (l *Lists) Push(ctx context.Context, data []byte) error {
	return l.rdb.LPush(ctx, "test_list", data).Err()
}

func (l *Lists) Pop(ctx context.Context) ([]byte, error) {
	return l.rdb.RPop(ctx, "test_list").Bytes()
}
