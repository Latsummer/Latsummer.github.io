package errorx

import (
	"errors"
	"github.com/gogf/gf/v2/errors/gcode"
)

var (
	ErrCodeInDegradation = gcode.New(11350001, "module in degradation", nil)
	ErrCodeParamInvalid  = gcode.New(11350002, "param invalid", nil)
	ErrCodeBiggerExist   = gcode.New(11350003, "bigger score task exist", nil)
)

var (
	// ErrBiggerExist 存在更大的分数的相同任务
	ErrBiggerExist = errors.New("member exist and score bigger")

	// ErrNoData 出队时任务data不存在
	ErrNoData = errors.New("pop get failed with no data")

	// ErrNil redis的nil错误
	ErrNil = errors.New("redis nil")

	// ErrMarshalFail 任务序列化失败
	ErrMarshalFail = errors.New("marshal failed")

	// ErrUnMarshalFail 任务反序列化失败
	ErrUnMarshalFail = errors.New("unmarshal failed")

	// ErrTaskListFull 任务队列已满
	ErrTaskListFull = errors.New("task list is full")

	// ErrMetaNoKey meta数据中没有对应项
	ErrMetaNoKey = errors.New("can not find key in meta")

	// ErrGptLimit Gpt模型返回并发限制
	ErrGptLimit = errors.New("gpt returns code 429")

	// ErrGptTimeout 访问Gpt模型超时
	ErrGptTimeout = errors.New("gpt request timeout")

	// ErrNoPlugin 没有对应数据类型的插件
	ErrNoPlugin = errors.New("no such plugin")

	ErrShouldRuminate = errors.New("task should ruminate")

	ErrShouldDelete = errors.New("task should delete")
)
