package consts

type (
	Priority int
)

// 优先级定义
const (
	NoneLevel Priority = iota
	LowestLevel
	LowLevel
	NormalLevel
	HighLevel
	HighestLevel
	LevelLen
)

const (
	GptResultBlack = 1
	GptResultWhite = 2
	GptResultGray  = 3
)
