/**
 * @breif: 配置中心模块错误码，错误码示例：101XXXXX，前3位固定101，后面5位表示错误码
 * @copyright: Copyright (c) 2024 深信服科技有限公司 All rights reserved.
 * @version: 1.0.0
 * @author: 陶鸿敏76543
 * @date: 2024-10-29
 */
package errcode

// HTTP 错误码
const (
	ERR_IS_LATEST_VERSION = 10100001 // 当前配置已经是最新版本
	ERR_MODULE_NOT_FOUND  = 10100002 // 未找到对应模块配置，终端没有对应模块配置
	ERR_UNKNOWN_FAILURE   = 10100003 // 未知的操作失败
)

// HTTP 错误信息
const (
	ERR_MSG_IS_LATEST_VERSION = "it is already the latest version" // 当前配置已经是最新版本
	ERR_MSG_MODULE_NOT_FOUND  = "module not found"                 // 未找到对应模块配置，终端没有对应模块配置
	ERR_MSG_UNKNOWN_FAILURE   = "unknown failure"                  // 未知的操作失败
)
