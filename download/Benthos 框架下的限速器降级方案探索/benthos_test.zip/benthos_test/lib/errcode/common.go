/**
 * @breif: 公共错误码，用于错误码的统一管理，错误码示例：100XXXXX，前3位固定100，表示模块ID，后面5位表示错误码
 * @copyright: Copyright (c) 2024 深信服科技有限公司 All rights reserved.
 * @version: 1.0.0
 * @author: 陶鸿敏76543
 * @date: 2024-10-29
 */
package errcode

import (
	"github.com/gogf/gf/v2/errors/gcode"
)

var (
	// CodeOK 成功
	CodeOK = gcode.New(0, "OK", nil)
	// CodeInternalError 内部错误
	CodeInternalError = gcode.New(10001001, "Internal Error", nil)
	// CodeValidationFailed 数据验证失败
	CodeValidationFailed = gcode.New(10001002, "Validation Failed", nil)
	// CodeInvalidParameter 参数错误
	CodeInvalidParameter = gcode.New(10001003, "Invalid Parameter", nil)
	// CodeNotSupported 操作不支持
	CodeNotSupported = gcode.New(10001004, "Not Supported", nil)
	// CodeOperationFailed 操作失败
	CodeOperationFailed = gcode.New(10001005, "Operation Failed", nil)
	// CodeNotAuthorized 未授权
	CodeNotAuthorized = gcode.New(10001006, "Not Authorized", nil)
	// CodeServerBusy 服务繁忙
	CodeServerBusy = gcode.New(10001007, "Server Is Busy", nil)

	// CodeNotFound 资源未找到
	CodeNotFound = gcode.New(10001008, "Not Found", nil)
)
