/**
 * @breif: pulsar模块错误码，错误码示例：102XXXXX，前3位固定102，后面5位表示错误码
 * @copyright: Copyright (c) 2024 深信服科技有限公司 All rights reserved.
 * @version: 1.0.0
 * @author: 敖宽12973
 * @date: 2024-10-29
 */
package errcode

// 错误码
const (
	ERR_PULSAR_CLIENT_UNINITIALIZED = 10200001 // pulsar未初始化连接
	ERR_PULSAR_CLIENT_INIT_FAILED   = 10200002 // pulsar初始化失败
	ERR_PULSAR_SUBSCRIBE_FAILED     = 10200003 // pulsar订阅失败
	ERR_PULSAR_AUTH_TOKEN_INVALID   = 10200004 // pulsar认证token无效

	ERR_CONTEXT_TENANT_EMPTY = 10210001 // 租户信息为空

	ERR_PULSAR_PRODUCER_CREATE_FAILED   = 10220001 // pulsar生产者创建失败
	ERR_PULSAR_PRODUCER_SEND_MSG_FAILED = 10220002 // pulsar生产者发送消息失败

	ERR_PULSAR_CONSUMER_CLOSED        = 10230001 // 消费者已关闭
	ERR_PULSAR_CONSUMER_RECEIVE       = 10230002 // 消费者接收消息出错
	ERR_PULSAR_CONSUMER_UNINITIALIZED = 10230003 // 消费者未初始化
)
