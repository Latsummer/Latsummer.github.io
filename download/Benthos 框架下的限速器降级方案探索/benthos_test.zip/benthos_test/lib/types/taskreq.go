package types

type TaskReq struct {
	Requester   string `json:"requester"`
	TaskType    string `json:"taskType"`
	TenantId    string `json:"tenantId"`
	AgentId     string `json:"agentId"`
	Priority    int    `json:"priority"`
	TaskId      string `json:"taskId"`
	Score       int64  `json:"score"`
	TaskContent string `json:"taskContent"`
}
