package types

import "time"

// TODO 使用LogTrace替代

// TaskTrace 任务各个关键时间节点
type TaskTrace struct {
	RequestTime           int64 // 请求时间
	EnqueueTime           int64 // 入队时间
	DequeueTime           int64 // 出队时间
	PreProcessTime        int64 // 预处理完成时间
	ProcessTime           int64 // 解读完成时间
	PostProcessTime       int64 // 后处理完成时间
	ProductTime           int64 // 生产结果时间
	RuminateCnt           int64 // 放入闲时队列的次数
	FirstPushRuminateTime int64 // 首次放入闲时任务处理时间
	LastPopRuminateTime   int64 // 最后一次从闲时处理取出的时间
}

func (t *TaskTrace) SetRequestTime() {
	t.RequestTime = nowUnixMicro()
}

func (t *TaskTrace) SetEnqueueTime() {
	t.EnqueueTime = nowUnixMicro()
}

func (t *TaskTrace) SetDequeueTime() {
	t.DequeueTime = nowUnixMicro()
}

func (t *TaskTrace) SetPreProcessTime() {
	t.PreProcessTime = nowUnixMicro()
}

func (t *TaskTrace) SetProcessTime() {
	t.ProcessTime = nowUnixMicro()
}

func (t *TaskTrace) SetPostProcessTime() {
	t.PostProcessTime = nowUnixMicro()
}

func (t *TaskTrace) SetProductTime() {
	t.ProductTime = nowUnixMicro()
}

func (t *TaskTrace) AddRuminateCnt() {
	t.RuminateCnt++
}

func (t *TaskTrace) SetFirstPushRuminateTime() {
	if t.FirstPushRuminateTime > 0 {
		return
	}
	t.FirstPushRuminateTime = time.Now().UnixMicro()
}

func (t *TaskTrace) SetLastPopRuminateTime() {
	t.LastPopRuminateTime = time.Now().UnixMicro()
}

func (t *TaskTrace) BuildTraceInfo() map[string]int64 {
	return map[string]int64{
		"RequestTime":           t.RequestTime,
		"EnqueueTime":           t.EnqueueTime,
		"DequeueTime":           t.DequeueTime,
		"PreProcessTime":        t.PreProcessTime,
		"ProcessTime":           t.ProcessTime,
		"PostProcessTime":       t.PostProcessTime,
		"ProductTime":           t.ProductTime,
		"RuminateCnt":           t.RuminateCnt,
		"FirstPushRuminateTime": t.FirstPushRuminateTime,
		"LastPopRuminateTime":   t.LastPopRuminateTime,
	}
}

func (t *TaskTrace) ToUnixMicro(n int64) time.Duration {
	return time.Duration(n) * time.Microsecond
}

func nowUnixMicro() int64 {
	return time.Now().UnixMicro()
}
