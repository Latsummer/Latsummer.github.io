package types

import (
	"benthos_test/lib/consts"
	"github.com/redpanda-data/benthos/v4/public/service"
	"time"
	"unicode"
)

type TaskContent struct {
	TaskTrace

	Requester string          // 请求方
	TaskType  string          // 任务类型
	TenantId  string          // 租户ID
	AgentId   string          // 终端ID
	TraceId   string          // trace id
	Priority  consts.Priority // 优先级
	TaskId    string          // 任务ID
	Score     int64           // 指定的调度分数
	Content   string          // 任务数据
}

type TaskProcess struct {
	*TaskContent
	ProcessChin   []string
	ProcessedData []byte
}

type GptResult struct {
	ResultStatus int    `json:"resultStatus"` // 黑白灰状态
	GptRequest   string `json:"gptRequest"`   // GPT请求的内容, 如果结果为黑则填充此项
	GptResponse  string `json:"gptResponse"`  // GPT的返回结果
}

type TaskResult struct {
	TaskId      string `json:"taskId"`
	Content     []byte `json:"content"`
	ProcessChin []string
	TraceInfo   map[string]int64
}

type MetaTrace map[string]int64

func (t *TaskContent) ToBenthosMessage() *service.Message {
	ret := service.NewMessage(nil)
	ret.SetStructuredMut(&TaskProcess{
		TaskContent:   t,
		ProcessChin:   make([]string, 0),
		ProcessedData: make([]byte, 0),
	})
	//ret.MetaSetMut("requester", t.Requester)
	ret.MetaSetMut("taskType", t.TaskType)
	ret.MetaSetMut("switchType", getIdStatus(t.TaskId))
	metaT := make(MetaTrace)
	metaT["input"] = time.Now().Unix()
	ret.MetaSetMut("metaTrace", metaT)
	//ret.MetaSetMut("tenantId", t.TenantId)
	//ret.MetaSetMut("agentId", t.AgentId)
	//ret.MetaSetMut("traceId", t.TraceId)
	//ret.MetaSetMut("priority", t.Priority)
	//ret.MetaSetMut("taskId", t.TaskId)
	return ret
}

func getIdStatus(id string) string {
	lastChar := rune(id[len(id)-1])

	if unicode.IsDigit(lastChar) {
		return "numType"
	}

	if unicode.IsUpper(lastChar) {
		return "strUpperType"
	}

	return "strLetterType"
}
