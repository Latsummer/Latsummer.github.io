package my_stdout

import (
	"context"
	"fmt"
	"github.com/redpanda-data/benthos/v4/public/service"
	"io"
	"os"
)

type myStdout struct {
	handle io.WriteCloser
}

func init() {
	err := service.RegisterOutput("my_stdout",
		service.NewConfigSpec().Stable().Field(service.NewIntField("max_in_flight").Default(1)),
		func(conf *service.ParsedConfig, mgr *service.Resources) (out service.Output, maxInFlight int, err error) {
			mif, _ := conf.FieldInt("max_in_flight")
			return &myStdout{handle: os.Stdout}, mif, nil
		})
	if err != nil {
		panic(err)
	}

	err = service.RegisterBatchOutput("my_stdout_batch",
		service.NewConfigSpec().Stable().Fields(
			service.NewIntField("max_in_flight").Default(1),
			service.NewBatchPolicyField("batching"),
		),
		newBatchStdout,
	)
	if err != nil {
		panic(err)
	}
}

func newBatchStdout(conf *service.ParsedConfig, mgr *service.Resources) (out service.BatchOutput, batchPolicy service.BatchPolicy, maxInFlight int, err error) {
	batching, err := conf.FieldBatchPolicy("batching")
	if err != nil {
		return nil, service.BatchPolicy{}, 0, err
	}
	mif, err := conf.FieldInt("max_in_flight")
	if err != nil {
		return nil, service.BatchPolicy{}, 0, err
	}

	return &myStdout{handle: os.Stdout}, batching, mif, nil
}

func (m *myStdout) Connect(ctx context.Context) error {
	return nil
}

func (m *myStdout) Write(ctx context.Context, message *service.Message) error {
	err := message.GetError()
	if err != nil {
		return err
	}

	msg, err := message.AsBytes()
	if err != nil {
		return err
	}

	newMsg := fmt.Sprintf("%s\n", string(msg))
	_, err = m.handle.Write([]byte(newMsg))
	if err != nil {
		return err
	}

	return nil
}

func (m *myStdout) WriteBatch(ctx context.Context, batch service.MessageBatch) error {
	return batch.WalkWithBatchedErrors(func(i int, message *service.Message) error {
		err := message.GetError()
		if err != nil {
			return err
		}

		msg, err := message.AsBytes()
		if err != nil {
			return err
		}

		newMsg := fmt.Sprintf("%s\n", string(msg))
		_, err = m.handle.Write([]byte(newMsg))
		if err != nil {
			return err
		}

		return nil
	})
}

func (m *myStdout) Close(ctx context.Context) error {
	return nil
}
