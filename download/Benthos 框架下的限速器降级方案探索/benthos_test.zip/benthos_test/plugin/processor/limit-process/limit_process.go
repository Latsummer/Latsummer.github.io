package limit_process

import (
	"benthos_test/lib/consts/errorx"
	"context"
	"github.com/pkg/errors"
	"github.com/redpanda-data/benthos/v4/public/service"
	"golang.org/x/time/rate"
	"math"
	"sync"
	"sync/atomic"
	"time"
)

const epsilon = 1e-9

type (
	limitProcess struct {
		log     *service.Logger
		limit   *rate.Limiter
		minEach rate.Limit
		maxEach rate.Limit

		wg           sync.WaitGroup
		shutdownChan chan struct{}
		cpuC         *cpuChecker
		msgC         *msgChecker
	}

	cpuChecker struct {
		checkInterval time.Duration
		cpuMax        float64
	}

	msgChecker struct {
		checkInterval time.Duration
		failureMax    float64
		sucCnt        atomic.Int32
		falCnt        atomic.Int32
	}
)

func init() {
	err := service.RegisterProcessor("limit_process",
		limitProcessConf(),
		newLimitProcess,
	)
	if err != nil {
		panic(err)
	}
}

func limitProcessConf() *service.ConfigSpec {
	res := service.NewConfigSpec()
	res.Stable().Summary("limit processor")
	res.Fields(
		service.NewFloatField("each"),
		service.NewFloatField("minEach").Optional(),
		service.NewFloatField("maxEach").Optional(),
		service.NewIntField("capacity"),
		service.NewObjectField("cpuChecker",
			service.NewDurationField("checkInterval"),
			service.NewFloatField("cpuMax"),
		).Optional(),
		service.NewObjectField("msgChecker",
			service.NewDurationField("checkInterval"),
			service.NewFloatField("failureMax"),
		).Optional(),
	)
	return res
}

func newLimitProcess(conf *service.ParsedConfig, mgr *service.Resources) (service.Processor, error) {
	each, err := conf.FieldFloat("each")
	if err != nil {
		return nil, err
	}

	capacity, err := conf.FieldInt("capacity")
	if err != nil {
		return nil, err
	}

	var (
		minEach             = rate.Limit(each)
		maxEach             = rate.Limit(each)
		cpuC    *cpuChecker = nil
		msgC    *msgChecker = nil
	)

	minEachCfg, err := conf.FieldFloat("minEach")
	if err == nil {
		minEach = rate.Limit(minEachCfg)
	}

	maxEachCfg, err := conf.FieldFloat("maxEach")
	if err == nil {
		maxEach = rate.Limit(maxEachCfg)
	}

	cpuCheckerCfg, err := conf.FieldObjectMap("cpuChecker")
	if err == nil {
		interval, err := cpuCheckerCfg["checkInterval"].FieldDuration()
		if err != nil {
			return nil, err
		}

		cpuMax, err := cpuCheckerCfg["cpuMax"].FieldFloat()
		if err != nil {
			return nil, err
		}

		cpuC = &cpuChecker{
			checkInterval: interval,
			cpuMax:        cpuMax,
		}
	}

	msgCheckerCfg, err := conf.FieldObjectMap("msgChecker")
	if err == nil {
		interval, err := msgCheckerCfg["checkInterval"].FieldDuration()
		if err != nil {
			return nil, err
		}

		failureMax, err := msgCheckerCfg["failureMax"].FieldFloat()
		if err != nil {
			return nil, err
		}

		msgC = &msgChecker{
			checkInterval: interval,
			failureMax:    failureMax,
		}
	}

	res := &limitProcess{
		log:          mgr.Logger(),
		limit:        rate.NewLimiter(rate.Limit(each), capacity),
		minEach:      minEach,
		maxEach:      maxEach,
		wg:           sync.WaitGroup{},
		shutdownChan: make(chan struct{}),
		cpuC:         cpuC,
		msgC:         msgC,
	}

	res.checkerStart()
	return res, nil
}

func (l *limitProcess) Process(ctx context.Context, message *service.Message) (service.MessageBatch, error) {
	l.recordMsg(message.GetError())
	err := l.limit.Wait(ctx)
	if err != nil {
		l.log.Errorf("limit process wait error, msg %v", err)
	}
	return service.MessageBatch{message}, nil
}

func (l *limitProcess) Close(_ context.Context) error {
	l.checkerStop()
	return nil
}

func (l *limitProcess) upgrade() {
	cur := l.limit.Limit()
	if isLimitEqual(cur, l.maxEach) {
		return
	}
	newLimit := cur * 2
	if newLimit > l.maxEach {
		newLimit = l.maxEach
	}

	l.log.Infof("limit processor upgrade, each from %.3f to %.3f, maxEach %.3f", cur, newLimit, l.maxEach)
	l.limit.SetLimit(newLimit)
}

func (l *limitProcess) downgrade() {
	cur := l.limit.Limit()
	if isLimitEqual(cur, l.minEach) {
		return
	}
	newLimit := cur / 2
	if newLimit < l.minEach {
		newLimit = l.minEach
	}

	l.log.Infof("limit processor downgrade, each from %.3f to %.3f, minEach %.3f", cur, newLimit, l.minEach)
	l.limit.SetLimit(newLimit)
}

func (l *limitProcess) checkerStart() {
	if l.cpuC != nil {
		l.log.Infof("process limit cpu checker start...")
		l.wg.Add(1)
		go l.cpuCheckerLoop()
	}

	if l.msgC != nil {
		l.log.Infof("process limit msg failure checker start...")
		l.wg.Add(1)
		go l.msgCheckerLoop()
	}
}

func (l *limitProcess) checkerStop() {
	close(l.shutdownChan)
	l.wg.Wait()
}

func (l *limitProcess) cpuCheckerLoop() {
	defer l.wg.Done()
	// 检查CPU使用率的代码...
}

func (l *limitProcess) msgCheckerLoop() {
	defer l.wg.Done()
	tc := time.NewTicker(l.msgC.checkInterval)
	defer tc.Stop()

	for {
		select {
		case <-l.shutdownChan:
			return
		case <-tc.C:
			sucCnt := l.msgC.sucCnt.Swap(0)
			falCnt := l.msgC.falCnt.Swap(0)
			allCnt := sucCnt + falCnt
			if allCnt == 0 {
				continue
			}

			failRate := float64(falCnt) / float64(allCnt)
			if failRate > l.msgC.failureMax {
				l.downgrade()
			} else {
				l.upgrade()
			}
		}
	}
}

func (l *limitProcess) recordMsg(err error) {
	if l.msgC == nil {
		return
	}

	if err != nil && errors.Is(err, errorx.ErrGptLimit) {
		l.msgC.falCnt.Add(1)
	} else {
		l.msgC.sucCnt.Add(1)
	}
}

func isLimitEqual(a, b rate.Limit) bool {
	return math.Abs(float64(a-b)) < epsilon
}
