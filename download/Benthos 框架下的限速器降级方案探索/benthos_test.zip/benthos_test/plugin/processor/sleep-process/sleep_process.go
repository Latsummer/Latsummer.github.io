package sleep_process

import (
	"benthos_test/lib/consts/errorx"
	"context"
	"encoding/json"
	"github.com/redpanda-data/benthos/v4/public/service"
	"strconv"
	"time"
)

type sleepProcess struct {
	log       *service.Logger
	oddSleep  time.Duration
	evenSleep time.Duration
}

func (s *sleepProcess) ProcessBatch(ctx context.Context, batch service.MessageBatch) ([]service.MessageBatch, error) {
	time.Sleep(s.oddSleep)
	return []service.MessageBatch{batch}, nil
}

type msgType struct {
	Message string `json:"message"`
	Meta    struct {
		ProcessTime time.Time `json:"process_time"`
	} `json:"meta"`
}

func init() {
	err := service.RegisterProcessor(
		"sleep_process",
		sleepProcessConfig(),
		newSleepProcess)
	if err != nil {
		panic(err)
	}

	err = service.RegisterBatchProcessor("sleep_process_batch",
		sleepProcessConfig(),
		func(c *service.ParsedConfig, m *service.Resources) (service.BatchProcessor, error) {
			oddSleep, err := c.FieldDuration("oddSleep")
			if err != nil {
				return nil, err
			}

			evenSleep, err := c.FieldDuration("evenSleep")
			if err != nil {
				return nil, err
			}

			return &sleepProcess{
				log:       m.Logger(),
				oddSleep:  oddSleep,
				evenSleep: evenSleep,
			}, nil
		})
	if err != nil {
		panic(err)
	}
}

func sleepProcessConfig() *service.ConfigSpec {
	spec := service.NewConfigSpec()
	spec.Stable().Summary("sleep process")
	spec.Fields(
		service.NewDurationField("oddSleep"),
		service.NewDurationField("evenSleep"),
	)
	return spec
}

func newSleepProcess(c *service.ParsedConfig, m *service.Resources) (service.Processor, error) {
	oddSleep, err := c.FieldDuration("oddSleep")
	if err != nil {
		return nil, err
	}

	evenSleep, err := c.FieldDuration("evenSleep")
	if err != nil {
		return nil, err
	}

	res := &sleepProcess{
		log:       m.Logger(),
		oddSleep:  oddSleep,
		evenSleep: evenSleep,
	}

	res.log.Infof("!!!! bala_sleep Init !!!!!!")
	return res, nil
}

func (s *sleepProcess) Process(ctx context.Context, message *service.Message) (service.MessageBatch, error) {
	//mErr := message.GetError()
	//if mErr != nil {
	//	return nil, mErr
	//}
	d, err := message.AsBytes()
	if err != nil {
		return nil, err
	}

	var newMsg msgType
	err = json.Unmarshal(d, &newMsg)
	if err != nil {
		return nil, err
	}

	n, err := strconv.ParseInt(newMsg.Message, 10, 0)
	if err != nil {
		panic(err)
	}
	if n < 20 {
		return service.MessageBatch{message}, errorx.ErrGptLimit
	}
	//
	//if isOdd(newMsg.Message) {
	//	time.Sleep(s.oddSleep)
	//	//newMsg.Message += "sleep"
	//} else {
	//	time.Sleep(s.evenSleep)
	//	//newMsg.Message += "sleep"
	//}
	//
	//message.SetStructuredMut(newMsg)
	//time.Sleep(s.oddSleep)

	return service.MessageBatch{message}, nil
}

func (s *sleepProcess) Close(_ context.Context) error {
	return nil
}

func isOdd(num string) bool {
	n, err := strconv.ParseInt(num, 10, 0)
	if err != nil {
		panic(err)
	}

	return n%2 != 0
}
