package rdbinput

import (
	"benthos_test/lib/lists"
	"context"
	"github.com/redpanda-data/benthos/v4/public/service"
)

type rdbInput struct {
	log  *service.Logger
	l    *lists.Lists
	each int
}

func init() {
	err := service.RegisterInput("rdb_input",
		newRdbInputConfig(),
		func(conf *service.ParsedConfig, mgr *service.Resources) (service.Input, error) {
			mif, err := conf.FieldInt("max_in_flight")
			if err != nil {
				return nil, err
			}
			return service.InputWithMaxInFlight(mif, &rdbInput{
				log: mgr.Logger(),
				l:   lists.GetLists(),
			}), nil
		})
	if err != nil {
		panic(err)
	}

	err = service.RegisterBatchInput("rdb_input_batch",
		newRdbInputConfig(),
		func(conf *service.ParsedConfig, mgr *service.Resources) (service.BatchInput, error) {
			mif, err := conf.FieldInt("max_in_flight")
			if err != nil {
				return nil, err
			}

			each, err := conf.FieldInt("each")
			if err != nil {
				return nil, err
			}

			return service.InputBatchedWithMaxInFlight(mif, &rdbInput{
				log:  mgr.Logger(),
				l:    lists.GetLists(),
				each: each,
			}), nil
		})
}

func newRdbInputConfig() *service.ConfigSpec {
	return service.NewConfigSpec().Stable().Fields(
		service.NewIntField("max_in_flight").Default(0),
		service.NewIntField("each").Optional(),
	)
}

func (r *rdbInput) Connect(ctx context.Context) error {
	return nil
}

func (r *rdbInput) Close(ctx context.Context) error {
	return nil
}

func (r *rdbInput) Read(ctx context.Context) (*service.Message, service.AckFunc, error) {
	if ctx.Err() != nil {
		return nil, nil, ctx.Err()
	}

	d, err := r.l.Pop(ctx)
	if err != nil {
		return nil, nil, err
	}

	msg := service.NewMessage(d)
	return msg, func(ctx context.Context, err error) error {
		//if err != nil {
		//	r.log.Infof("get err %v", err)
		//}
		return nil
	}, nil
}

func (r *rdbInput) ReadBatch(ctx context.Context) (service.MessageBatch, service.AckFunc, error) {
	if ctx.Err() != nil {
		return nil, nil, ctx.Err()
	}

	res := make(service.MessageBatch, 0)

	for i := 0; i < r.each; i++ {
		d, err := r.l.Pop(ctx)
		if err != nil {
			return nil, nil, err
		}
		msg := service.NewMessage(d)
		res = append(res, msg)
	}

	return res, func(ctx context.Context, err error) error {
		if err != nil {
			r.log.Infof("get err %v", err)
		}
		return nil
	}, nil
}
