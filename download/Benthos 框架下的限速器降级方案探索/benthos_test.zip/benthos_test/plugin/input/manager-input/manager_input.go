package managerinput

import (
	"benthos_test/lib/errcode"
	"benthos_test/lib/response"
	"benthos_test/lib/types"
	"context"
	"encoding/json"
	"github.com/pkg/errors"
	"github.com/redpanda-data/benthos/v4/public/service"
	"go.opentelemetry.io/otel"
	"go.opentelemetry.io/otel/attribute"
	"go.opentelemetry.io/otel/metric"
	semconv "go.opentelemetry.io/otel/semconv/v1.30.0"
	"io"
	"net/http"
	"sync"
	"time"
)

var (
	paramErr = errors.New("config param error")
)

const (
	fieldAddress = "address"
	fieldRoutes  = "routes"
	fieldTimeout = "timeout"
)

func init() {
	err := service.RegisterInput("manager_input", newManagerInputConfig(), newManagerInput)
	if err != nil {
		panic(err)
	}
}

type managerInput struct {
	address string
	routes  []string
	server  *http.Server
	timeout time.Duration

	log          *service.Logger
	msgChan      chan *service.Message
	shutdownChan chan struct{}
	wg           *sync.WaitGroup

	// metrics
	// 请求处理耗时统计
	reqLatencyHist metric.Int64Histogram
	// 请求数统计
	reqCounter metric.Int64Counter
}

func newManagerInputConfig() *service.ConfigSpec {
	res := service.NewConfigSpec().Stable()
	res.Summary("manager input")
	res.Description("BALA BALA")
	res.Fields(
		service.NewStringField(fieldAddress).Description("address"),
		service.NewStringListField(fieldRoutes).Description("routes"),
		service.NewDurationField(fieldTimeout).Default("server timeout"),
	)
	return res
}

func newManagerInput(conf *service.ParsedConfig, mgr *service.Resources) (service.Input, error) {
	addr, err := conf.FieldString(fieldAddress)
	if err != nil {
		return nil, errors.Wrapf(paramErr, "err: %v", err)
	}

	routes, err := conf.FieldStringList(fieldRoutes)
	if err != nil {
		return nil, errors.Wrapf(paramErr, "err: %v", err)
	}

	timeout, err := conf.FieldDuration(fieldTimeout)
	if err != nil {
		return nil, errors.Wrapf(paramErr, "err: %v", err)
	}

	res := &managerInput{
		address:        addr,
		routes:         routes,
		server:         nil,
		timeout:        timeout,
		log:            mgr.Logger(),
		msgChan:        make(chan *service.Message, 1),
		shutdownChan:   make(chan struct{}),
		wg:             &sync.WaitGroup{},
		reqLatencyHist: nil,
		reqCounter:     nil,
	}

	meter := otel.Meter("manager_input")
	res.reqLatencyHist, err = meter.Int64Histogram("http_request_latency",
		metric.WithDescription("http request duration in ms"),
		metric.WithUnit("ms"),
		metric.WithExplicitBucketBoundaries(100, 200, 300, 500, 1000, 2000, 5000, 10000),
	)
	if err != nil {
		return nil, errors.Wrapf(paramErr, "err: %v", err)
	}

	res.reqCounter, err = meter.Int64Counter("http_request_count", metric.WithUnit("1"))

	res.log.Infof("new input, timeout %d, addr %s, routes %v", res.timeout/time.Second, res.address, res.routes)
	res.loopStart()
	return res, nil
}

func (m *managerInput) Connect(ctx context.Context) error {
	m.log.Info("now connect !")
	return nil
}

func (m *managerInput) Read(ctx context.Context) (*service.Message, service.AckFunc, error) {
	m.log.Infof("123 RRRead")
	select {
	case msg := <-m.msgChan:
		nMsg, _ := msg.WithSyncResponseStore()
		return nMsg, func(ctx context.Context, err error) error {
			return nil
		}, nil

	case <-m.shutdownChan:
		return nil, nil, service.ErrNotConnected
	case <-ctx.Done():
		return nil, nil, ctx.Err()
	}
}

func (m *managerInput) Close(ctx context.Context) error {
	close(m.shutdownChan)
	m.loopStop(ctx)
	return nil
}

func (m *managerInput) loopStart() {
	mux := http.NewServeMux()
	for _, one := range m.routes {
		m.log.Infof("register handler func %s", one)
		mux.HandleFunc(one, m.handlerRequest)
	}

	m.server = &http.Server{
		Addr:    m.address,
		Handler: mux,
	}

	m.log.Infof("start manager input server on %s", m.address)
	m.wg.Add(1)
	go m.loop()
}

func (m *managerInput) loop() {
	defer m.wg.Done()
	err := m.server.ListenAndServe()
	if err != nil && !errors.Is(err, http.ErrServerClosed) {
		m.log.Errorf("HTTP server error %v", err)
	}
}

func (m *managerInput) loopStop(ctx context.Context) {
	if m.server != nil {
		_ = m.server.Shutdown(ctx)
		m.wg.Wait()
	}
}

func (m *managerInput) handlerRequest(w http.ResponseWriter, r *http.Request) {
	var err error
	start := time.Now()
	w.Header().Set("Content-Type", "application/json")
	rw := response.NewResponseWriter(w)

	defer func() {
		interval := time.Since(start)
		attr := []attribute.KeyValue{
			semconv.HTTPRequestMethodKey.String(r.Method),
			semconv.HTTPRouteKey.String(r.URL.Path),
			semconv.HTTPRequestBodySize(int(r.ContentLength)),
			semconv.HTTPResponseStatusCode(rw.Status()),
			attribute.Int("errcode", rw.Errcode()),
		}

		m.reqCounter.Add(r.Context(), 1, metric.WithAttributes(attr...))
		m.reqLatencyHist.Record(r.Context(), interval.Milliseconds())
	}()

	task, err := m.parseReq(r)
	if err != nil {
		m.log.Warnf("failed to parse request: %v", err)
		_ = rw.ResponseErrcode(errcode.CodeInvalidParameter)
		return
	}

	msg := m.buildMsg(task)
	err = m.sendMsg(r.Context(), rw, msg)
	if err != nil {
		m.log.Warnf("send msg failed, %v", err)
		return
	}

	return
}

func (m *managerInput) parseReq(r *http.Request) (*types.TaskReq, error) {
	body, err := io.ReadAll(r.Body)
	if err != nil {
		return nil, err
	}
	defer r.Body.Close()

	var task types.TaskReq
	err = json.Unmarshal(body, &task)
	if err != nil {
		return nil, err
	}

	return &task, nil
}

func (m *managerInput) buildMsg(task *types.TaskReq) *service.Message {
	msg := service.NewMessage([]byte(task.TaskContent))
	msg.MetaSet("requester", task.Requester)
	msg.MetaSet("taskType", task.TaskType)
	msg.MetaSet("tenantId", task.TenantId)
	msg.MetaSet("agentId", task.AgentId)
	msg.MetaSetMut("priority", task.Priority)
	msg.MetaSet("taskId", task.TaskId)

	return msg
}

func (m *managerInput) sendMsg(ctx context.Context, rw response.ResponseWriter, msg *service.Message) error {
	timeoutCtx, cancel := context.WithTimeout(ctx, m.timeout)
	defer cancel()

	select {
	case <-timeoutCtx.Done():
		_ = rw.ResponseErrcode(errcode.CodeServerBusy)
		return timeoutCtx.Err()
	case m.msgChan <- msg:
		//_ = rw.ResponseSuccess("ok")
		return nil
	}
}
