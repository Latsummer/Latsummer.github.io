package mut_rate_limit_local

import (
	"context"
	"github.com/redpanda-data/benthos/v4/public/service"
	"sync"
	"time"
)

var gLimit mutRateLimitLocal

func limiterConfig() *service.ConfigSpec {
	spec := service.NewConfigSpec().Stable()
	spec.Summary("variable local rate limit")
	spec.Fields(
		service.NewIntField("benchCount"),
		service.NewIntField("minCount"),
		service.NewIntField("maxCount").Optional(),
		service.NewDurationField("interval").Default("1s"),
	)

	return spec
}

func init() {
	err := service.RegisterRateLimit("mut_rate_limit_local",
		limiterConfig(), newMutRateLimitLocal)
	if err != nil {
		panic(err)
	}
}

type mutRateLimitLocal struct {
	log         *service.Logger
	mut         sync.Mutex
	curSize     int
	lastRefresh time.Time

	minSize   int
	benchSize int
	maxSize   int
	period    time.Duration
}

func newMutRateLimitLocal(conf *service.ParsedConfig, mgr *service.Resources) (service.RateLimit, error) {
	benchCount, err := conf.FieldInt("benchCount")
	if err != nil {
		return nil, err
	}
	minCount, err := conf.FieldInt("minCount")
	if err != nil {
		return nil, err
	}
	interval, err := conf.FieldDuration("interval")
	if err != nil {
		return nil, err
	}

	maxCount, err := conf.FieldInt("maxCount")
	if err != nil {
		maxCount = benchCount
	}

	gLimit = mutRateLimitLocal{
		log:         mgr.Logger(),
		mut:         sync.Mutex{},
		minSize:     minCount,
		curSize:     benchCount,
		maxSize:     maxCount,
		lastRefresh: time.Now(),
		benchSize:   benchCount,
		period:      interval,
	}

	gLimit.log.Infof("I am Init !!!!!!")
	return &gLimit, nil
}

func (m *mutRateLimitLocal) Access(ctx context.Context) (time.Duration, error) {
	m.mut.Lock()
	m.curSize--

	if m.curSize < 0 {
		m.curSize = 0
		remaining := m.period - time.Since(m.lastRefresh)

		if remaining > 0 {
			m.mut.Unlock()
			return remaining, nil
		}
		m.curSize = m.benchSize - 1
		m.lastRefresh = time.Now()
	}
	m.mut.Unlock()
	return 0, nil
}

func (m *mutRateLimitLocal) Close(_ context.Context) error {
	return nil
}

func Upgrade() {
	gLimit.mut.Lock()
	defer gLimit.mut.Unlock()

	ori := gLimit.benchSize
	gLimit.benchSize *= 2
	if gLimit.benchSize > gLimit.maxSize {
		gLimit.benchSize = gLimit.maxSize
	}

	gLimit.log.Infof("limiter upgrade from %d to %d", ori, gLimit.benchSize)
}

func DownGrade() {
	gLimit.mut.Lock()
	defer gLimit.mut.Unlock()

	ori := gLimit.benchSize
	gLimit.benchSize /= 2
	if gLimit.benchSize < gLimit.minSize {
		gLimit.benchSize = gLimit.minSize
	}
	gLimit.log.Infof("limiter downGrade from %d to %d", ori, gLimit.benchSize)
}
