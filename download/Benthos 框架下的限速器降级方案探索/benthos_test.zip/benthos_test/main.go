package main

import (
	"benthos_test/lib/lists"
	_ "benthos_test/plugin/input/manager-input"
	_ "benthos_test/plugin/input/rdb-input"
	_ "benthos_test/plugin/output/my-stdout"
	_ "benthos_test/plugin/processor/limit-process"
	_ "benthos_test/plugin/processor/sleep-process"
	_ "benthos_test/plugin/rate_limit/mut_rate_limit_local"
	"context"
	_ "github.com/redpanda-data/benthos/v4/public/components/io"
	_ "github.com/redpanda-data/benthos/v4/public/components/pure"
	_ "github.com/redpanda-data/benthos/v4/public/components/pure/extended"
	"github.com/redpanda-data/benthos/v4/public/service"
	"strconv"
)

func main() {
	l := lists.GetLists()
	for i := 1; i <= 100; i++ {
		_ = l.Push(context.Background(), []byte(strconv.Itoa(i)))
	}

	//limi := rate.NewLimiter(rate.Limit(2), 1)
	//for i := 0; i < 10; i++ {
	//	err := limi.Wait(context.Background())
	//	if err != nil {
	//		fmt.Printf("get err %v\n", err)
	//	}
	//	fmt.Println(time.Now().Unix())
	//}
	service.RunCLI(context.Background())
}
